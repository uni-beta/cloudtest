package com.unibeta.cloudtest.assertion;

/**
 * A basic assert object model that is used for vRules4j engine.
 * 
 * @author jordan.xue
 * 
 */
public class CloudTestAssert {
  String assertRule;

  public String getAssertRule() {
    return assertRule;
  }

  public void setAssertRule(String assertRule) {
    this.assertRule = assertRule;
  }

}
