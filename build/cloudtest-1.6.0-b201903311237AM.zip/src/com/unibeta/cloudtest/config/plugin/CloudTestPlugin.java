package com.unibeta.cloudtest.config.plugin;

/**
 * A super interface for cloud test plugin service. every plguin service should
 * implement this interface.
 * 
 * @author jordan.xue
 * 
 */
public interface CloudTestPlugin {

}
